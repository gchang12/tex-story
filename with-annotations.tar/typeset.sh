if [ -z "$1" ]; then
    cmd="pdflatex main";
else
    cmd="pdflatex --jobname="$1" main";
fi
python3 note-checker.py && $cmd && $cmd
